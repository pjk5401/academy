from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def form():
    if request.method == 'POST':
        name = request.form.get('name')
        age = request.form.get('age')
        food = request.form.get('food')
        return render_template('result.html', name=name, age=age, food=food)
    return render_template('form.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=, debug=True)

# pip install flask
# pip isntall flask-cors
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# 메모리 내 사용자 목록
users = [
    {"id": 1, "name": "Kim", "age": 20},
    {"id": 2, "name": "Lee", "age": 23},
    {"id": 3, "name": "Park", "age": 25},
    {"id": 4, "name": "Choi", "age": 27},
    {"id": 5, "name": "Robert", "age": 30}
]

# 모든 사용자 조회
@app.route('/api/users', methods=['GET'])
def get_users():
    return jsonify(users)

# 특정 사용자 조회
@app.route('/api/user/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = next((u for u in users if u['id'] == user_id), None)
    if user:
        return jsonify(user)
    return jsonify({"error": "User not found"}), 404

# 사용자 추가
@app.route('/api/user', methods=['POST'])
def add_user():
    data = request.get_json()
    if not data or 'name' not in data or 'age' not in data:
        return jsonify({"error": "Invalid data"}), 400

    new_id = max([u['id'] for u in users], default=0) + 1
    new_user = {
        "id": new_id,
        "name": data['name'],
        "age": data['age']
    }
    users.append(new_user)
    return jsonify(new_user), 201

# 사용자 수정
@app.route('/api/user/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    user = next((u for u in users if u['id'] == user_id), None)
    if not user:
        return jsonify({"error": "User not found"}), 404

    data = request.get_json()
    user['name'] = data.get('name', user['name'])
    user['age'] = data.get('age', user['age'])
    return jsonify(user)

# 사용자 삭제
@app.route('/api/user/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    global users
    if not any(u['id'] == user_id for u in users):
        return jsonify({"error": "User not found"}), 404
    users = [u for u in users if u['id'] != user_id]
    return jsonify({"result": f"User {user_id} deleted"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=, debug=True) # 외부 포트
    # app.run(host='127.0.0.1', port=50xx, debug=True) # 내부 포트

// const API_URL = "http://116.124.191.174:15001/api";  // 외부 백엔드 REST API 주소
const API_URL = "http://127.0.0.1:5000/api";  // 내부 백엔드 REST API 주소

const userList = document.getElementById("user-list");
const userForm = document.getElementById("user-form");

// 사용자 목록 불러오기
function loadUsers() {
    fetch(`${API_URL}/users`)
        .then(res => res.json())
        .then(data => {
            userList.innerHTML = '';
            data.forEach(user => {
                const li = document.createElement("li");
                li.textContent = `${user.id}. ${user.name} (${user.age}세)`;
                userList.appendChild(li);
            });
        });
}

// 사용자 추가
userForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const age = parseInt(document.getElementById("age").value, 10);

    fetch(`${API_URL}/user`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, age }),
    })
    .then(res => res.json())
    .then(() => {
        userForm.reset();
        loadUsers();
    });
});

// 초기 사용자 목록 로딩
loadUsers();

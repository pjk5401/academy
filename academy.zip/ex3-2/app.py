from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return "🔢 숫자를 더하려면 /add/숫자1/숫자2 경로로 접속하세요."

@app.route('/add/<int:a>/<int:b>')
def add(a, b):
    result = a + b
    return render_template('result.html', a=a, b=b, result=result)

# 404 에러 커스터마이징
@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html'), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=, debug=True)

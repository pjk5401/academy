import os
from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector

app = Flask(__name__)
CORS(app)

db_config = {
    'host': os.environ.get('MYSQL_HOST'),
    'user': os.environ.get('MYSQL_USER'),
    'password': os.environ.get('MYSQL_PASSWORD'),
    'database': os.environ.get('MYSQL_DATABASE')
}

# 사용자 전체 조회
@app.route('/api/users', methods=['GET'])
def get_users():
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM user")
    users = cursor.fetchall()
    conn.close()
    return jsonify(users)

# 특정 사용자 조회
@app.route('/api/user/<int:user_id>', methods=['GET'])
def get_user(user_id):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM user WHERE id = %s", (user_id,))
    user = cursor.fetchone()
    conn.close()
    if user:
        return jsonify(user)
    return jsonify({'error': 'User not found'}), 404

# 사용자 추가
@app.route('/api/user', methods=['POST'])
def add_user():
    data = request.get_json()
    name = data.get('name')
    age = data.get('age')
    if not name or age is None:
        return jsonify({'error': 'Invalid data'}), 400

    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO user (name, age) VALUES (%s, %s)", (name, age))
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()
    return jsonify({'id': new_id, 'name': name, 'age': age}), 201

# 사용자 수정
@app.route('/api/user/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    data = request.get_json()
    name = data.get('name')
    age = data.get('age')

    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("UPDATE user SET name=%s, age=%s WHERE id=%s", (name, age, user_id))
    conn.commit()
    conn.close()
    return jsonify({'id': user_id, 'name': name, 'age': age})

# 사용자 삭제
@app.route('/api/user/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM user WHERE id = %s", (user_id,))
    conn.commit()
    conn.close()
    return jsonify({'result': f'User {user_id} deleted'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=50xx, debug=True)

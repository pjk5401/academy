from flask import Flask, render_template

app = Flask(__name__)

# 기본 루트 경로
@app.route('/')
def home():
    return "📍 이것은 메인 페이지입니다."

# 정적 라우트
@app.route('/about')
def about():
    return "📘 이 페이지는 About 페이지입니다."

# 동적 라우트 - 이름을 URL로 전달
@app.route('/hello/<name>')
def hello(name):
    return render_template('hello.html', name=name)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=, debug=True)
